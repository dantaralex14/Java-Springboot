import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.tsa.stattools import adfuller
from scipy import stats
from statsmodels.tsa.seasonal import seasonal_decompose
from sklearn.ensemble import IsolationForest
import random

st.title("Proyecto de ejercicios de 2da Parcial")
st.title("Alumno: Dantar Alejandro Ortiz Vega")
st.write("Facultad de Ingeniería Mecánica y Eléctrica")
st.write("Ingeniería en Computación Inteligente")
st.write("Profesor: Walter Alexander Mata Lopez")
st.write("Sexto semestre grupo D")
st.write("24 de abril del 2024")

st.sidebar.title("Bienvenido")
opciones_analisis = ['Serie Temporal', 'Estacionariedad', 'Ventas', 'Salarios']
seleccion = st.sidebar.selectbox('Seleccione el análisis:', opciones_analisis)

def generar_serie_temporal():
    np.random.seed(0)
    t = np.arange(120)
    data = 20 + 0.05 * t + 10 * np.sin(2 * np.pi * t / 12) + np.random.normal(size=120)
    serie_temporal = pd.Series(data, index=pd.date_range(start='2010-01-01', periods=120, freq='M'))
    return serie_temporal

def visualizar_serie_temporal(serie_temporal):
    st.write("### Serie Temporal")
    st.write("Viendo la serie temporal que se generó con el primer código se observa el incremento lento que tuvo en los años, teniendo un valor de entre 20-30 grados a partir del 2010 hasta inicios del 2018 donde empezó a sobrepasar los 35 grados. Eso fue en la visualización y en cuanto a la transformación, se modificó dando otra gráfica diferenciada donde podemos ver la perturbación de la serie temporal con 'ruido', afectándola demasiado. En el último punto Dickey-Fuller nos da el valor estadístico respecto a las dos series generadas. Como verán, la diferencia es significativa en la prueba estadística en la serie original y en la diferenciada, pero esto quiere decir que la serie diferenciada es estacionaria. Esto implicaría que la estacionalidad se eliminaron de cierta forma y bueno, esos fueron las conclusiones que obtuve con respecto a los datos de ambas series.")
    st.line_chart(serie_temporal)

def diferenciar_serie_temporal(serie_temporal):
    serie_diferenciada = serie_temporal.diff().dropna()
    st.write("### Serie Temporal Diferenciada")
    st.line_chart(serie_diferenciada)
    return serie_diferenciada

def prueba_dickey_fuller(serie):
    result = adfuller(serie)
    st.write('#### Prueba de Dickey-Fuller Aumentada:')
    st.write('Estadístico de prueba:', result[0])
    st.write('Valor p:', result[1])
    st.write('Valores críticos:')
    for key, value in result[4].items():
        st.write(f'\t{key}: {value:.3f}')

def generar_datos_temperatura_anomalias():
    np.random.seed(0)
    random.seed(0)
    
    Fecha_inicio = pd.to_datetime('2023-01-01')
    Fecha_fin = pd.to_datetime('2023-06-30')
    Fecha_rango = pd.date_range(start=Fecha_inicio, end=Fecha_fin, freq='H')

    temperature_data = pd.DataFrame({
        'Fecha': Fecha_rango,
        'Temperatura': np.random.normal(loc=70, scale=5, size=len(Fecha_rango))
    })

    anomaly_indices = random.sample(range(len(Fecha_rango)), k=10)
    temperature_data.loc[anomaly_indices, 'Temperatura'] += np.random.normal(loc=20, scale=5, size=len(anomaly_indices))    
    st.write("## Lecturas de temperatura de sensores")
    st.write("### Datos de temperatura con anomalías")
    st.line_chart(temperature_data.set_index('Fecha'))

    return temperature_data, anomaly_indices

def analizar_datos_temperatura_anomalias(temperature_data, anomaly_indices):
    st.write("## Análisis de datos")
    st.write("### 1. ¿Existen lecturas de temperatura que se desvíen significativamente del rango esperado para esa área de la planta?")
    st.write("Sí, hay lecturas de temperatura que se desvían significativamente, especialmente en junio de 2023.")

    st.write("### 2. ¿Hay algún patrón o tendencia en las lecturas anómalas?")
    st.write("Las lecturas anómalas no siguen un patrón claro, pero tienden a concentrarse alrededor de ciertos períodos de tiempo, como finales o inicios de meses.")

    st.write("### 3. ¿Qué características tienen las lecturas anómalas en comparación con las lecturas normales?")
    st.write("Las lecturas anómalas se caracterizan por desviarse significativamente del rango esperado y no seguir un patrón consistente.")

    st.write("### Conclusiones")
    st.write("Se observaron lecturas anómalas en el primer semestre de 2023, con cierta concentración en junio. Estas anomalías podrían deberse a fallas en los equipos. Se deben tomar medidas para evitar lecturas tan abruptas como las mostradas, especialmente aquellas que podrían tener consecuencias significativas.")

def generar_ventas():
    Fechas = pd.date_range(start='2022-01-01', end='2024-04-30', freq='M')
    Productos = ['Laptops', 'Celulares', 'Smartwatch']
    Ventas = []

    for fecha in Fechas:
        ventas_Laptops = random.randint(100, 300)
        ventas_Celulares = random.randint(150, 400)
        ventas_Smartwatch = random.randint(200, 500)
        Ventas.append([ventas_Laptops, ventas_Celulares, ventas_Smartwatch])

    df_ventas = pd.DataFrame(Ventas, columns=Productos, index=Fechas)
    return df_ventas

def analizar_ventas(df_ventas):
    st.write("## Análisis de Ventas")
    st.write("En lo que a mi respecta, el patrón estacional de los productos podría deberse a las tendencias que hay o por moda, es decir, por el uso y el incremento en la fabricación de estos porque siento que es más accesible para alguien por el uso de su celular.")

    st.write("En crecimiento como ya lo dije fue de los smartwatches que fue por la accesibilidad que uno tiene por tener un celular y poder enlazarlo a este pero en decrecimiento fue los celulares que en opinión es por el alto precio que suelen tener estos como la marca iPhone que al tener ciertas características que los diferencia de otras marcas la demanda si que es grande con esta.")

    st.write("Unicamente me percate de junio-julio del 2022 que en el producto de laptops si hubo un bajón considerable en sus productos pero en meses posteriores logró nivelarse o más bien mantenerse sin tener bajones o subidas se mantuvo estable en cuanto a los otros productos permanecían bien con subidas y bajones en algunas ocasiones pero todo bien y esto. Bueno, el único resultado al que llegué, el cual fue obvio para mí, fue la venta de los smartwatches que fue la que tuvo una gran venta en estos 3 años. En la primera gráfica que hice marqué como x el tope que tuvieron los smartwatches porque es una enorme cantidad que llegaron a vender en uno de los trimestres del 2023 en comparación de los demás productos que si bien no tuvieron malas ventas no se comparan a lo que los smartwatches tuvieron como las laptops y celulares que tuvieron una venta aceptable.")

    for producto in df_ventas.columns:
        fig1, ax1 = plt.subplots(figsize=(12, 6))
        ax1.plot(df_ventas.index, df_ventas[producto], label=producto)

        ax1.set_title('Ventas Mensuales de Productos')
        ax1.set_xlabel('Fecha')
        ax1.set_ylabel('Ventas')
        ax1.legend()
        ax1.grid(True)
        plt.xticks(rotation=45)
        plt.tight_layout()
        st.pyplot(fig1)

def generar_estadisticas_salarios():
    np.random.seed(5015)

    salarios = np.random.normal(loc=50000, scale=15000, size=250)
    salarios = np.round(salarios, -3)

    salarios = np.abs(salarios)

    media = np.mean(salarios)
    mediana = np.median(salarios)
    moda_result = stats.mode(salarios)
    moda = moda_result.mode.item() if not np.isscalar(moda_result.mode) else [moda_result.mode]

    varianza = np.var(salarios)
    desv_std = np.std(salarios)

    st.write("## Estadísticas descriptivas de los salarios generados:")
    st.write("Los resultados de la mediana y la media en mi manera de interpretarlos sería el promedio de los salarios anuales y la mediana sería, en cuyo caso, la suma de todos los salarios divididos entre 2 si el resultado fuese impar o en cuyo caso si este fuera par, sería el valor salarial que estuviera en el centro de la lista de los salarios. Así es una forma en la que yo lo veo, pasando a la moda sería la cantidad del salario que le correspondió a cada trabajador, cantidad repetida que puede que fuera en la mayor parte de los trabajadores, la cantidad más repetida era la de 4000 para arriba siendo 59000 el más destacado. Siguiendo hablando todavía de los salarios diría que están algo cercanos a la media más no tan alejados como uno pensaría por su interpretación u otras ideas y por último después de haber graficado los datos podría decir que sí es una gran cantidad al ver la moda y puede interpretarse el gran salario que la mayoría de los trabajadores tienen y se espera que el ambiente laboral sea digno para un trabajador y cumpla la empresa con su respectiva política del trabajo.")

    fig, axs = plt.subplots(1, 2, figsize=(12, 6))

    axs[0].hist(salarios, bins=20, color='skyblue', edgecolor='black', alpha=0.7)
    axs[0].set_title('Histograma de Salarios')
    axs[0].set_xlabel('Salario')
    axs[0].set_ylabel('Frecuencia')

    axs[1].hist(salarios, bins=20, density=True, color='skyblue', edgecolor='black', alpha=0.7)
    axs[1].set_title('Densidad de Salarios')
    axs[1].set_xlabel('Salario')
    axs[1].set_ylabel('Densidad')

    if moda is not None:
        axs[0].axvline(moda[0], color='orange', linestyle='dashed', linewidth=1, label=f'Moda: {moda[0]:.2f}')
    axs[0].axvline(media, color='red', linestyle='dashed', linewidth=1, label=f'Media: {media:.2f}')
    axs[0].axvline(mediana, color='green', linestyle='dashed', linewidth=1, label=f'Mediana: {mediana:.2f}')
    axs[0].axvline(varianza, color='blue', linestyle='dashed', linewidth=1, label=f'Varianza: {varianza:.2f}')
    axs[0].axvline(desv_std, color='purple', linestyle='dashed', linewidth=1, label=f'Desv_std: {desv_std:.2f}')
    axs[0].legend()

    st.pyplot(fig)

    return salarios

def main():
    if seleccion == 'Serie Temporal':
        serie_temporal = generar_serie_temporal()
        visualizar_serie_temporal(serie_temporal)
        serie_diferenciada = diferenciar_serie_temporal(serie_temporal)
        st.write('\n#### Pruebas de Estacionariedad:')
        st.write('Para la Serie Temporal Original:')
        prueba_dickey_fuller(serie_temporal)
        st.write('\nPara la Serie Temporal Diferenciada:')
        prueba_dickey_fuller(serie_diferenciada)
    elif seleccion == 'Ventas':
        st.write("## Análisis de Ventas")
        df_ventas = generar_ventas()
        analizar_ventas(df_ventas)
    elif seleccion == 'Salarios':
        generar_estadisticas_salarios()
    elif seleccion == 'Estacionariedad':
        temperature_data, anomaly_indices = generar_datos_temperatura_anomalias()
        analizar_datos_temperatura_anomalias(temperature_data, anomaly_indices)

if __name__ == "__main__":
    main()
