import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;

public class mongo {
    public static void main(String[] args) {
        try (MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017")) {
            MongoDatabase database = mongoClient.getDatabase("Pruebas");
            System.out.println("Conexión exitosa a la base de datos MongoDB");
        } catch (Exception e) {
            System.err.println("Error al conectar a la base de datos: " + e.getMessage());
        }
    }
}
