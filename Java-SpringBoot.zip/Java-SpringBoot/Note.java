@Entity
public class Note {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private String content;

    // Getters y Setters
}

@Repository
public interface NoteRepository extends JpaRepository<Note, Long> {
}
