@RestController
@RequestMapping("/api/notes")
public class NoteController {

    @Autowired
    private NoteRepository noteRepository;

    @GetMapping("/")
    public List<Note> getAllNotes() {
        return noteRepository.findAll();
    }

    @PostMapping("/")
    public Note createNewNote(@RequestBody Note note) {
        return noteRepository.save(note);
    }
}
