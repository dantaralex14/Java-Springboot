import java.sql.*;

public class basedatos {
    public static void main(String[] args) {
        String url = "jdbc:postgresql://localhost:5432/Dante";
        String usuario = "postgres";
        String contraseña = "DANTAR";
        try (Connection conexion = DriverManager.getConnection(url, usuario, contraseña)) {
            System.out.println("Conexión exitosa a la base de datos Dante");
            String sqlInsert = "INSERT INTO usuario (id, nombre, no_de_cuenta) VALUES (?, ?, ?)";
            try (PreparedStatement statement = conexion.prepareStatement(sqlInsert)) {
                statement.setString(1, "10P2i");
                statement.setString(2, "Alexander");
                statement.setString(3, "12346");
                int filasInsertadas = statement.executeUpdate();
                System.out.println("Filas insertadas: " + filasInsertadas);
            }

            String sqlSelect = "SELECT id, nombre, no_de_cuenta FROM usuario";
            try (Statement statement = conexion.createStatement();
                    ResultSet resultSet = statement.executeQuery(sqlSelect)) {
                while (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    String nombre = resultSet.getString("nombre");
                    String no_de_cuenta = resultSet.getString("no_de_cuenta");
                    System.out.println("ID: " + id + ", Nombre: " + nombre + ", No. de Cuenta: " + no_de_cuenta);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
        }
    }
}
