CREATE TABLE UserProfile (
    user_id SERIAL PRIMARY KEY,
    full_name VARCHAR(100),
	email VARCHAR (100),
    age INTEGER,
	city VARCHAR(100),
	country VARCHAR(100),
 	phone VARCHAR(20),
    gender VARCHAR(10),
    height DECIMAL(5, 2),
    weight DECIMAL(5, 2)
);

CREATE TABLE DoctorProfile (
    doctor_id SERIAL PRIMARY KEY,
    full_name VARCHAR(100),
	email VARCHAR (100),
    age INTEGER,
	city VARCHAR(100),
	country VARCHAR(100),
 	phone VARCHAR(20)
);

CREATE TABLE HospitalProfile (
    Hospital_id SERIAL PRIMARY KEY,
    Hospital_name VARCHAR(100),
	email VARCHAR (100),
	city VARCHAR(100),
	country VARCHAR(100),
 	phone VARCHAR(20),
	postal_code VARCHAR(20),
	street VARCHAR(100),
 	exterior_number VARCHAR(20),
 	interior_number VARCHAR(20)
);

CREATE TABLE PhysicalActivity (
    activity_id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES UserProfile(user_id),
    activity_type VARCHAR(50),
    start_date_and_time TIMESTAMP,
    duration INTERVAL,
    distance DECIMAL(8, 2),
    calories_burned DECIMAL(8, 2),
    average_heart_rate INTEGER,
    maximum_heart_rate INTEGER
);


CREATE TABLE Sleep (
    sleep_id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES UserProfile(user_id),
    date DATE,
    start_time TIME,
    end_time TIME,
    total_sleep_duration INTERVAL,
    awakenings_during_night INTEGER
);


CREATE TABLE Health (
    health_id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES UserProfile(user_id),
    registration_date_and_time TIMESTAMP,
    blood_pressure VARCHAR(20),
    blood_oxygen_level DECIMAL(5, 2),
    heart_rate INTEGER
);


CREATE TABLE Notifications (
    notification_id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES UserProfile(user_id),
    notification_type VARCHAR(50),
    notification_content TEXT,
    reception_date_and_time TIMESTAMP,
    notification_status VARCHAR(10)
);


SELECT * FROM Notificaciones; 





