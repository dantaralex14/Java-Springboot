import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Serie temporal con valores sobre los puntos
data = pd.DataFrame({
    'Fecha': pd.date_range(start='2024-01-01', periods=10, freq='M'),
    'Valor': [100, 120, 130, 125, 145, 160, 155, 150, 165, 170]
})
data.set_index('Fecha', inplace=True)

plt.figure(figsize=(10, 6))
plt.plot(data.index, data['Valor'], marker='o', linestyle='-', color='b')

for fecha, valor in zip(data.index, data['Valor']):
    plt.text(fecha, valor, str(valor), ha='center', va='bottom', fontsize=9)

plt.title('Evolución del Valor a lo Largo del Tiempo')
plt.xlabel('Fecha')
plt.ylabel('Valor')
plt.grid(True)
plt.xticks(rotation=45)
plt.tight_layout()

plt.show()

# Gráfico de barras de ventas por producto
productos = ['Producto A', 'Producto B', 'Producto C', 'Producto D']
ventas = [23, 45, 56, 78]

plt.figure(figsize=(8, 5))
plt.bar(productos, ventas)
plt.title('Ventas por Producto')
plt.xlabel('Producto')
plt.ylabel('Ventas')
plt.show()

# Gráfico de barras con dos series
categorias = ['Categoría 1', 'Categoría 2', 'Categoría 3', 'Categoría 4']
serie1 = [20, 35, 30, 35]
serie2 = [25, 32, 34, 20]
barWidth = 0.3
r1 = np.arange(len(serie1))
r2 = [x + barWidth for x in r1]

plt.figure(figsize=(8, 5))
plt.bar(r1, serie1, color='blue', width=barWidth, edgecolor='grey', label='Serie 1')
plt.bar(r2, serie2, color='red', width=barWidth, edgecolor='grey', label='Serie 2')
plt.xlabel('Categoría', fontweight='bold')
plt.xticks([r + barWidth for r in range(len(serie1))], categorias)
plt.legend()
plt.show()
